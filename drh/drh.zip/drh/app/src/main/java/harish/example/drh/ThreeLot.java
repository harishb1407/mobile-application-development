package harish.example.drh;

public class ThreeLot {

    private Float lot_pack_1, bag_pack_1, nobag_pack_1, gross_pack_1, tare_pack_1, net_pack_1, lot_pack_2, bag_pack_2, nobag_pack_2, gross_pack_2, tare_pack_2, net_pack_2;
    private Float lot_pack_3, bag_pack_3, nobag_pack_3, gross_pack_3, tare_pack_3, net_pack_3;

    public ThreeLot() {
    }

    public Float getLot_pack_1() {
        return lot_pack_1;
    }

    public void setLot_pack_1(Float lot_pack_1) {
        this.lot_pack_1 = lot_pack_1;
    }

    public Float getBag_pack_1() {
        return bag_pack_1;
    }

    public void setBag_pack_1(Float bag_pack_1) {
        this.bag_pack_1 = bag_pack_1;
    }

    public Float getNobag_pack_1() {
        return nobag_pack_1;
    }

    public void setNobag_pack_1(Float nobag_pack_1) {
        this.nobag_pack_1 = nobag_pack_1;
    }

    public Float getGross_pack_1() {
        return gross_pack_1;
    }

    public void setGross_pack_1(Float gross_pack_1) {
        this.gross_pack_1 = gross_pack_1;
    }

    public Float getTare_pack_1() {
        return tare_pack_1;
    }

    public void setTare_pack_1(Float tare_pack_1) {
        this.tare_pack_1 = tare_pack_1;
    }

    public Float getNet_pack_1() {
        return net_pack_1;
    }

    public void setNet_pack_1(Float net_pack_1) {
        this.net_pack_1 = net_pack_1;
    }

    public Float getLot_pack_2() {
        return lot_pack_2;
    }

    public void setLot_pack_2(Float lot_pack_2) {
        this.lot_pack_2 = lot_pack_2;
    }

    public Float getBag_pack_2() {
        return bag_pack_2;
    }

    public void setBag_pack_2(Float bag_pack_2) {
        this.bag_pack_2 = bag_pack_2;
    }

    public Float getNobag_pack_2() {
        return nobag_pack_2;
    }

    public void setNobag_pack_2(Float nobag_pack_2) {
        this.nobag_pack_2 = nobag_pack_2;
    }

    public Float getGross_pack_2() {
        return gross_pack_2;
    }

    public void setGross_pack_2(Float gross_pack_2) {
        this.gross_pack_2 = gross_pack_2;
    }

    public Float getTare_pack_2() {
        return tare_pack_2;
    }

    public void setTare_pack_2(Float tare_pack_2) {
        this.tare_pack_2 = tare_pack_2;
    }

    public Float getNet_pack_2() {
        return net_pack_2;
    }

    public void setNet_pack_2(Float net_pack_2) {
        this.net_pack_2 = net_pack_2;
    }

    public Float getLot_pack_3() {
        return lot_pack_3;
    }

    public void setLot_pack_3(Float lot_pack_3) {
        this.lot_pack_3 = lot_pack_3;
    }

    public Float getBag_pack_3() {
        return bag_pack_3;
    }

    public void setBag_pack_3(Float bag_pack_3) {
        this.bag_pack_3 = bag_pack_3;
    }

    public Float getNobag_pack_3() {
        return nobag_pack_3;
    }

    public void setNobag_pack_3(Float nobag_pack_3) {
        this.nobag_pack_3 = nobag_pack_3;
    }

    public Float getGross_pack_3() {
        return gross_pack_3;
    }

    public void setGross_pack_3(Float gross_pack_3) {
        this.gross_pack_3 = gross_pack_3;
    }

    public Float getTare_pack_3() {
        return tare_pack_3;
    }

    public void setTare_pack_3(Float tare_pack_3) {
        this.tare_pack_3 = tare_pack_3;
    }

    public Float getNet_pack_3() {
        return net_pack_3;
    }

    public void setNet_pack_3(Float net_pack_3) {
        this.net_pack_3 = net_pack_3;
    }
}
