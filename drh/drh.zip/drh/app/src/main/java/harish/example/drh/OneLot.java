package harish.example.drh;

public class OneLot {
    private Float lot_pack, bag_pack, nobag_pack, gross_pack, tare_pack, net_pack;

    public OneLot() {
    }

    public Float getLot_pack() {
        return lot_pack;
    }

    public void setLot_pack(Float lot_pack) {
        this.lot_pack = lot_pack;
    }

    public Float getBag_pack() {
        return bag_pack;
    }

    public void setBag_pack(Float bag_pack) {
        this.bag_pack = bag_pack;
    }

    public Float getNobag_pack() {
        return nobag_pack;
    }

    public void setNobag_pack(Float nobag_pack) {
        this.nobag_pack = nobag_pack;
    }

    public Float getGross_pack() {
        return gross_pack;
    }

    public void setGross_pack(Float gross_pack) {
        this.gross_pack = gross_pack;
    }

    public Float getTare_pack() {
        return tare_pack;
    }

    public void setTare_pack(Float tare_pack) {
        this.tare_pack = tare_pack;
    }

    public Float getNet_pack() {
        return net_pack;
    }

    public void setNet_pack(Float net_pack) {
        this.net_pack = net_pack;
    }
}
