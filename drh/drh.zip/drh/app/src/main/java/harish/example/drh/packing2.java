package harish.example.drh;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class packing2 extends AppCompatActivity {

    EditText lot_pack, bag_pack, nobag_pack, gross_pack, tare_pack, net_pack;
    Spinner spin2_pack;
    Button addlot_pack, view_pack;
    Intent intent_lots;
    Pack pack2;

    DatabaseReference reff_pack2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_packing2);

        lot_pack = findViewById(R.id.lot_pack);
        bag_pack = findViewById(R.id.bag_pack);
        nobag_pack = findViewById(R.id.nobag_pack);
        gross_pack = findViewById(R.id.gross_pack);
        tare_pack = findViewById(R.id.tare_pack);
        net_pack = findViewById(R.id.net_pack);
        spin2_pack = findViewById(R.id.spin2_pack);
        addlot_pack = findViewById(R.id.addlot_pack);
        view_pack = findViewById(R.id.view_pack);

       /* spin2_pack.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                if (parent.getItemAtPosition(position).equals("1")){
                    intent_lots = new Intent (packing2.this, lot1.class);
                }
                if (parent.getItemAtPosition(position).equals("2")){
                    intent_lots = new Intent (packing2.this, lot2.class);
                }
                if (parent.getItemAtPosition(position).equals("3")){
                    intent_lots = new Intent (packing2.this, lot3.class);
                }
                if (parent.getItemAtPosition(position).equals("4")){
                    intent_lots = new Intent (packing2.this, lot4.class);
                }
            }



            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        view_pack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(intent_lots);
            }
        });

        */


        pack2 = new Pack();
        reff_pack2 = FirebaseDatabase.getInstance().getReference().child("Pack");
        addlot_pack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                int edit_text_lotnumber_pack = Integer.parseInt(lot_pack.getText().toString().trim());

                pack2.setEdit_text_lotnumber_pack(edit_text_lotnumber_pack);

                reff_pack2.push().setValue(pack2);

            }
        });



    }
}