package harish.example.drh;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class certificate extends AppCompatActivity {


    Spinner spin1_cert, spin2_cert, spin3_cert;
    EditText quantity_cert, lot_cert, purity_cert;
    Button add_cert, view_cert;
    DatabaseReference reff_cert;
    Cert cert;

    public static String productname_cert, appearance_cert, tlc_cert;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_certificate);

        spin1_cert = (Spinner)findViewById(R.id.spin1_cert);
        spin2_cert = (Spinner)findViewById(R.id.spin2_cert);
        spin3_cert = (Spinner)findViewById(R.id.spin3_cert);
        quantity_cert = (EditText)findViewById(R.id.quantity_cert);
        lot_cert = (EditText)findViewById(R.id.lot_cert);
        purity_cert = (EditText)findViewById(R.id.purity_cert);
        add_cert = (Button)findViewById(R.id.add_cert);
        view_cert = (Button)findViewById(R.id.view_cert);

        spin1_cert = (Spinner)findViewById(R.id.spin1_cert);
        spin2_cert = (Spinner)findViewById(R.id.spin2_cert);
        spin3_cert = (Spinner)findViewById(R.id.spin3_cert);

        spin1_cert.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                productname_cert = spin1_cert.getSelectedItem().toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        spin2_cert.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                appearance_cert = spin2_cert.getSelectedItem().toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        spin3_cert.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                tlc_cert = spin3_cert.getSelectedItem().toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });


        cert = new Cert();
        reff_cert = FirebaseDatabase.getInstance().getReference().child("Cert");

        add_cert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                float edit_text_quantity_cert = Float.parseFloat((quantity_cert.getText().toString().trim()));
                float edit_text_purity_cert = Float.parseFloat((purity_cert.getText().toString().trim()));
                int edit_text_lot_cert = Integer.parseInt(lot_cert.getText().toString().trim());


                cert.setEdit_text_quantity_cert(edit_text_quantity_cert);
                cert.setEdit_text_purity_cert(edit_text_purity_cert);
                cert.setEdit_text_lot_cert(edit_text_lot_cert);
                cert.setProductname_cert(productname_cert);
                cert.setAppearance_cert(appearance_cert);
                cert.setTlc_cert(tlc_cert);

                reff_cert.push().setValue(cert);


            }
        });
    }
}