package harish.example.drh;

public class Member {
    private Float edit_text_quantity;

    public Member() {
    }

    public Float getEdit_text_quantity() {
        return edit_text_quantity;
    }

    public void setEdit_text_quantity(Float edit_text_quantity) {
        this.edit_text_quantity = edit_text_quantity;
    }
}
