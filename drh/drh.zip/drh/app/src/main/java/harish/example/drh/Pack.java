package harish.example.drh;

public class Pack {
    private String edit_text_to_pack, edit_text_name_pack, productname_pack;
    private Integer edit_text_packnumber_pack;
    private Float edit_text_quantity_pack;



    private Integer edit_text_lotnumber_pack;



    public Pack() {
    }

    public String getEdit_text_to_pack() {
        return edit_text_to_pack;
    }

    public void setEdit_text_to_pack(String edit_text_to_pack) {
        this.edit_text_to_pack = edit_text_to_pack;
    }

    public String getEdit_text_name_pack() {
        return edit_text_name_pack;
    }

    public void setEdit_text_name_pack(String edit_text_name_pack) {
        this.edit_text_name_pack = edit_text_name_pack;
    }

    public String getProductname_pack() {
        return productname_pack;
    }

    public void setProductname_pack(String productname_pack) {
        this.productname_pack = productname_pack;
    }

    public Integer getEdit_text_packnumber_pack() {
        return edit_text_packnumber_pack;
    }

    public void setEdit_text_packnumber_pack(Integer edit_text_packnumber_pack) {
        this.edit_text_packnumber_pack = edit_text_packnumber_pack;
    }

    public Float getEdit_text_quantity_pack() {
        return edit_text_quantity_pack;
    }

    public void setEdit_text_quantity_pack(Float edit_txt_quantity_pack) {
        this.edit_text_quantity_pack = edit_txt_quantity_pack;
    }








    public Integer getEdit_text_lotnumber_pack() {
        return edit_text_lotnumber_pack;
    }

    public void setEdit_text_lotnumber_pack(Integer edit_text_lotnumber_pack) {
        this.edit_text_lotnumber_pack = edit_text_lotnumber_pack;
    }





}
