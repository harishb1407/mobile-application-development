package harish.example.drh;

import android.widget.Spinner;

public class Cert {
    private Float edit_text_quantity_cert, edit_text_purity_cert;
    private Integer edit_text_lot_cert;
    private String productname_cert, appearance_cert, tlc_cert;

    public Cert() {
    }

    public Float getEdit_text_quantity_cert() {
        return edit_text_quantity_cert;
    }

    public void setEdit_text_quantity_cert(Float edit_text_quantity_cert) {
        this.edit_text_quantity_cert = edit_text_quantity_cert;
    }

    public Float getEdit_text_purity_cert() {
        return edit_text_purity_cert;
    }

    public void setEdit_text_purity_cert(Float edit_text_purity_cert) {
        this.edit_text_purity_cert = edit_text_purity_cert;
    }

    public Integer getEdit_text_lot_cert() {
        return edit_text_lot_cert;
    }

    public void setEdit_text_lot_cert(Integer edit_text_lot_cert) {
        this.edit_text_lot_cert = edit_text_lot_cert;
    }

    public String getProductname_cert() {
        return productname_cert;
    }

    public void setProductname_cert(String productname_cert) {
        this.productname_cert = productname_cert;
    }

    public String getAppearance_cert() {
        return appearance_cert;
    }

    public void setAppearance_cert(String appearance_cert) {
        this.appearance_cert = appearance_cert;
    }

    public String getTlc_cert() {
        return tlc_cert;
    }

    public void setTlc_cert(String tlc_cert) {
        this.tlc_cert = tlc_cert;
    }
}
